﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7._3_Module4
{
    public partial class Form1 : Form
    {
        private delegate int AsyncSumm(int a, int b);

        public Form1()
        {
            InitializeComponent();
        }

        private int Summ(int a, int b)
        {
            Thread.Sleep(9000);
            return a + b;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            int a, b;
            try
            {
                a = Int32.Parse(txbA.Text);
                b = Int32.Parse(txbB.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("При выполнении преобразования типов возникла ошибка");
                txbA.Text = txbB.Text = "";
                return;
            }

            AsyncSumm summdelegate = new AsyncSumm(Summ);
            AsyncCallback cb = new AsyncCallback(CallBackMethod);
            summdelegate.BeginInvoke(a, b, cb, summdelegate);
        }

        private void CallBackMethod(IAsyncResult ar)
        {
            AsyncSumm summdelegate = (AsyncSumm)ar.AsyncState;
            string result = string.Format("Сумма введенных чисел равна {0}", summdelegate.EndInvoke(ar));
            MessageBox.Show(result, "Результат операции");
        }

        private void btnWork_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Работа кипит!!!");
        }

        private async Task RunTaskAsync(int a, int b)
        {
            await Task.Delay(9000);
            int result = a + b;
            labelTaskResult.Text = "Результат: " + result.ToString();
        }

        private void buttonTask_Click(object sender, EventArgs e)
        {
            int a, b;
            try
            {
                a = Int32.Parse(txbA.Text);
                b = Int32.Parse(txbB.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка ввода данных");
                return;
            }

            RunTaskAsync(a, b);
        }
    }
}
