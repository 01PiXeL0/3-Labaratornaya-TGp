﻿using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string s = "";             // Строка для хранения всего текста из файла
        string[] strings = new string[0];     // Инициализация пустого массива строк
        int ArrayCounter = 0;      // Счётчик для отслеживания текущей строки в массиве

        // Метод для обработки события печати страницы
        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            if (strings == null || strings.Length == 0)
            {
                MessageBox.Show("Файл не загружен или пуст.");
                e.Cancel = true; // Отменяем печать, если массив строк пуст
                return;
            }

            float LeftMargin = e.MarginBounds.Left;
            float TopMargin = e.MarginBounds.Top;
            float MyLines = e.MarginBounds.Height / this.Font.GetHeight(e.Graphics);
            float YPosition;
            int Counter = 0;
            string CurrentLine;

            while (Counter < MyLines && ArrayCounter < strings.Length)
            {
                CurrentLine = strings[ArrayCounter];
                YPosition = TopMargin + Counter * this.Font.GetHeight(e.Graphics);
                e.Graphics.DrawString(CurrentLine, this.Font, Brushes.Black, LeftMargin, YPosition, new StringFormat());
                Counter++;
                ArrayCounter++;
            }

            e.HasMorePages = ArrayCounter < strings.Length;
        }

        // Кнопка настройки страницы
        private void button1_Click(object sender, EventArgs e)
        {
            pageSetupDialog1.ShowDialog();
        }

        // Кнопка печати с диалогом печати
        private void button2_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
                printDocument1.Print();
        }

        // Кнопка предварительного просмотра
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 aForm = new Form2();

            // Связываем printDocument1 с PrintPreviewControl на Form2
            aForm.printPreviewControl1.Document = printDocument1;

            DialogResult aResult = aForm.ShowDialog();

            if (aResult == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        // Кнопка для загрузки файла
        private void button4_Click(object sender, EventArgs e)
        {
            var aResult = openFileDialog1.ShowDialog();
            if (aResult == DialogResult.OK)
            {
                System.IO.StreamReader aReader = new System.IO.StreamReader(openFileDialog1.FileName);
                s = aReader.ReadToEnd();
                aReader.Close();
                strings = s.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                ArrayCounter = 0; // Сбрасываем счётчик строк
            }
        }
        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
        }
    }
}
