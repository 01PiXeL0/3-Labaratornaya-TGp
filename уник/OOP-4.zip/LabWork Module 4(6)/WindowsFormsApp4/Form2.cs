﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void numericUpDownRows_ValueChanged(object sender, EventArgs e)
        {
           printPreviewControl1.Rows = (int)numericUpDownRows.Value;
        }

        private void numericUpDownColumns_ValueChanged(object sender, EventArgs e)
        {
            printPreviewControl1.Columns = (int)numericUpDownColumns.Value;
        }

        private void numericUpDownZoom_ValueChanged(object sender, EventArgs e)
        {
            printPreviewControl1.Zoom = (double)numericUpDownZoom.Value / 100;
        }

        private void checkBoxAntiAlias_CheckedChanged(object sender, EventArgs e)
        {
            printPreviewControl1.UseAntiAlias = checkBoxAntiAlias.Checked;
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
