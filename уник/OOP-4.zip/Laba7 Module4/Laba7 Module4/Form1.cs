﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba7_Module4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.WorkerSupportsCancellation = true;
            backgroundWorker1.DoWork += backgroundWorker1_DoWork;
            backgroundWorker1.ProgressChanged += backgroundWorker1_ProgressChanged;
            backgroundWorker1.RunWorkerCompleted += backgroundWorker1_RunWorkerCompleted;
        }

        // Упражнение 1: BackgroundWorker
        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxSeconds.Text, out int seconds))
            {
                progressBar1.Value = 0;
                backgroundWorker1.RunWorkerAsync(seconds);
            }
            else
            {
                MessageBox.Show("Введите корректное число секунд.");
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            if (backgroundWorker1.IsBusy)
                backgroundWorker1.CancelAsync();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            int seconds = (int)e.Argument;
            for (int i = 1; i <= seconds; i++)
            {
                if (backgroundWorker1.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }

                Thread.Sleep(1000); // Имитация работы
                backgroundWorker1.ReportProgress(i * 100 / seconds);
            }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show("Процесс отменен.");
            }
            else
            {
                MessageBox.Show("Процесс завершен.");
            }
        }

        // Упражнение 2: Async Delegate
        private delegate int CalculateDelegate(int a, int b);

        private void buttonAsyncDelegate_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxA.Text, out int a) && int.TryParse(textBoxB.Text, out int b))
            {
                CalculateDelegate calculate = (x, y) => x + y;
                calculate.BeginInvoke(a, b, AsyncDelegateCallback, calculate);
            }
            else
            {
                MessageBox.Show("Введите корректные значения для A и B.");
            }
        }

        private void AsyncDelegateCallback(IAsyncResult ar)
        {
            var calculate = (CalculateDelegate)ar.AsyncState;
            int result = calculate.EndInvoke(ar);
            Invoke(new Action(() => MessageBox.Show("Результат: " + result)));
        }

        // Упражнение 3: Task
        private void buttonTask_Click(object sender, EventArgs e)
        {
            RunTask();
        }

        private async void RunTask()
        {
            int result = await Task.Run(() => LongRunningTask());
            labelTaskResult.Text = "Результат: " + result;
        }

        private int LongRunningTask()
        {
            Thread.Sleep(2000); // Имитация долгой операции
            return new Random().Next(100); // Рандомный результат
        }
    }
}
