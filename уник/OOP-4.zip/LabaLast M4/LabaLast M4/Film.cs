﻿namespace LabaLast_M4
{   
    public class Film
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Duration { get; set; } // продолжительность в минутах
        public decimal Price { get; set; } // цена билета
    }
}
