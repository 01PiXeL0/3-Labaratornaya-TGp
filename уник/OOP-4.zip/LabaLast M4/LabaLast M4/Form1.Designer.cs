﻿namespace LabaLast_M4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvFilms = new System.Windows.Forms.DataGridView();
            this.txtFilterGenre = new System.Windows.Forms.TextBox();
            this.cmbFilms = new System.Windows.Forms.ComboBox();
            this.lstSessions = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFilms)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvFilms
            // 
            this.dgvFilms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFilms.Location = new System.Drawing.Point(12, 58);
            this.dgvFilms.Name = "dgvFilms";
            this.dgvFilms.Size = new System.Drawing.Size(510, 234);
            this.dgvFilms.TabIndex = 0;
            // 
            // txtFilterGenre
            // 
            this.txtFilterGenre.Location = new System.Drawing.Point(422, 39);
            this.txtFilterGenre.Name = "txtFilterGenre";
            this.txtFilterGenre.Size = new System.Drawing.Size(100, 20);
            this.txtFilterGenre.TabIndex = 1;
            this.txtFilterGenre.TextChanged += new System.EventHandler(this.txtFilterGenre_TextChanged);
            // 
            // cmbFilms
            // 
            this.cmbFilms.FormattingEnabled = true;
            this.cmbFilms.Location = new System.Drawing.Point(12, 38);
            this.cmbFilms.Name = "cmbFilms";
            this.cmbFilms.Size = new System.Drawing.Size(121, 21);
            this.cmbFilms.TabIndex = 2;
            this.cmbFilms.SelectedIndexChanged += new System.EventHandler(this.cmbFilms_SelectedIndexChanged);
            // 
            // lstSessions
            // 
            this.lstSessions.FormattingEnabled = true;
            this.lstSessions.Location = new System.Drawing.Point(528, 58);
            this.lstSessions.Name = "lstSessions";
            this.lstSessions.Size = new System.Drawing.Size(183, 30);
            this.lstSessions.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 378);
            this.Controls.Add(this.lstSessions);
            this.Controls.Add(this.cmbFilms);
            this.Controls.Add(this.txtFilterGenre);
            this.Controls.Add(this.dgvFilms);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvFilms)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvFilms;
        private System.Windows.Forms.TextBox txtFilterGenre;
        private System.Windows.Forms.ComboBox cmbFilms;
        private System.Windows.Forms.ListBox lstSessions;
    }
}

