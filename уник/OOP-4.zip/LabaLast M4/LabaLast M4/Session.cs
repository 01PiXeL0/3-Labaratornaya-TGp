﻿using System;

namespace LabaLast_M4
{
    public class Session
    {
        public Film Film { get; set; }
        public DateTime StartTime { get; set; }
        public int AvailableSeats { get; set; }
    }
}
