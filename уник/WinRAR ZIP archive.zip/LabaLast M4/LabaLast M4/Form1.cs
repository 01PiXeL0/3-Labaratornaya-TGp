﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace LabaLast_M4
{
    public partial class Form1 : Form
    {
        private List<Film> films;
        private List<Session> sessions;

        public Form1()
        {
            InitializeComponent();
            InitializeData();
        }

        // Инициализация данных для фильмов и сеансов
        private void InitializeData()
        {
            // Пример данных для фильмов с реальными названиями на русском языке
            films = new List<Film>
            {
                new Film { Title = "Интерстеллар", Genre = "Фантастика, Драма", Duration = 169, Price = 18.50m },
                new Film { Title = "Титаник", Genre = "Драма, Мелодрама", Duration = 195, Price = 20.00m },
                new Film { Title = "Начало", Genre = "Боевик, Приключения, Фантастика", Duration = 148, Price = 19.00m },
                new Film { Title = "Матрица", Genre = "Боевик, Фантастика", Duration = 136, Price = 18.50m },
                new Film { Title = "Побег из Шоушенка", Genre = "Драма", Duration = 142, Price = 15.50m },
                new Film { Title = "Темный рыцарь", Genre = "Боевик, Криминал, Драма", Duration = 152, Price = 20.00m },
                new Film { Title = "Гладиатор", Genre = "Боевик, Драма, История", Duration = 155, Price = 17.50m },
                new Film { Title = "Форрест Гамп", Genre = "Драма, Мелодрама", Duration = 142, Price = 17.00m },
                new Film { Title = "Властелин колец: Возвращение короля", Genre = "Боевик, Фэнтези, Драма", Duration = 201, Price = 22.00m },
                new Film { Title = "Крёстный отец", Genre = "Криминал, Драма", Duration = 175, Price = 18.00m }
            };

            // Пример данных для сеансов
            sessions = new List<Session>
            {
                new Session { Film = films[0], StartTime = DateTime.Now.AddHours(1), AvailableSeats = 30 },
                new Session { Film = films[1], StartTime = DateTime.Now.AddHours(2), AvailableSeats = 25 },
                new Session { Film = films[2], StartTime = DateTime.Now.AddHours(3), AvailableSeats = 20 },
                new Session { Film = films[3], StartTime = DateTime.Now.AddHours(4), AvailableSeats = 15 }
            };

            // Инициализируем ComboBox с названиями фильмов
            cmbFilms.DataSource = films;
            cmbFilms.DisplayMember = "Title";

            // Инициализируем DataGridView с фильмами сразу при запуске
            dgvFilms.DataSource = films;  // Заполнение DataGridView сразу всеми фильмами
        }

        // Метод для фильтрации фильмов по жанру
        private void FilterFilmsByGenre()
        {
            var filteredFilms = films.Where(f => f.Genre.IndexOf(txtFilterGenre.Text, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            dgvFilms.DataSource = filteredFilms;  // Обновляем отображение в DataGridView
        }

        // Метод для отображения сеансов для выбранного фильма
        private void ShowSessions()
        {
            var selectedFilm = cmbFilms.SelectedItem as Film;
            if (selectedFilm != null)
            {
                var filmSessions = sessions.Where(s => s.Film == selectedFilm).ToList();
                lstSessions.Items.Clear();
                foreach (var session in filmSessions)
                {
                    lstSessions.Items.Add($"{session.StartTime}: {session.AvailableSeats} seats available");
                }
            }
        }

        // Обработчик изменения текста в TextBox для фильтрации по жанру
        private void txtFilterGenre_TextChanged(object sender, EventArgs e)
        {
            FilterFilmsByGenre();
        }

        // Обработчик изменения выбранного фильма в ComboBox
        private void cmbFilms_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowSessions();
        }
    }
}
